# delta-method
A Python module that performs delta method calculations.
